#!/bin/bash
# v20 nur canon, archive.org part: download the md5-pinned archive.org OCR files, build 7 works into
# corpus/nur/, rebuild catalogs/works_index.tsv, record checksums and MANIFEST rows, update CORPUS_LOCATIONS.
set -euo pipefail
python3 pipeline/works/ingest_nur_archive.py --repo . --build
python3 - <<'PY'
import sys, os, glob, hashlib, csv
sys.path.insert(0, 'pipeline/repo'); import add_works_batch as a
a.build_index('.')
def sha(p):
    h = hashlib.sha256()
    with open(p, 'rb') as f:
        for c in iter(lambda: f.read(1 << 20), b''): h.update(c)
    return h.hexdigest()
keys = [r['key'] for r in csv.DictReader(open('catalogs/nur_archive.tsv', encoding='utf-8'), delimiter='\t')]
new = sorted([f'corpus/nur/{k}.jsonl.gz' for k in keys] + glob.glob('sources/archive/nur/*/*') +
             ['catalogs/nur_archive.tsv', 'catalogs/nur_archive_manifest.json',
              'pipeline/works/ingest_nur_archive.py', 'docs/nur/README.md'])
have = {l.split('\t')[0] for l in open('MANIFEST.tsv', encoding='utf-8')}
with open('MANIFEST.tsv', 'a', encoding='utf-8') as m, open('sources/checksums/v20_SHA256SUMS', 'w') as c:
    for p in new:
        h = sha(p); c.write(f'{h}  {p}\n')
        if p not in have: m.write(f'{p}\t{h}\t{os.path.getsize(p)}\tv20\t{os.path.basename(p)}\n')
L = open('CORPUS_LOCATIONS.md', encoding='utf-8').read().splitlines(keepends=True)
add = (" **v20** adds 7 works from archive.org OCR (catalogs/nur_archive.tsv, ocr_uncorrected): al-Jili's al-Insan al-kamil, "
       "al-Qaysari's and al-Qashani's Fusus commentaries, the Taiyya commentaries of al-Farghani, al-Qaysari and al-Qashani, "
       "and Suhrawardi's Hikmat al-ishraq. |")
for k, l in enumerate(L):
    if l.startswith('| corpus/nur/') and 'v20' not in l:
        L[k] = l.rstrip('\n').rstrip().rstrip('|').rstrip() + add + '\n'
open('CORPUS_LOCATIONS.md', 'w', encoding='utf-8').writelines(L)
print('v20 applied:', len(glob.glob('corpus/nur/*')), 'works in corpus/nur')
PY
