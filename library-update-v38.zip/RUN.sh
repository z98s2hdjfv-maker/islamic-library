#!/bin/bash
# v38: rebuild the concept index with the sense filter (cues/exclude in catalogs/concepts.tsv). Never blocks the update.
python3 pipeline/index/build_concept_index.py --repo . || echo "::warning::concept index not rebuilt"
python3 - <<'PY'
import glob, hashlib, os
pats = ["reports/index/concept_index.tsv.gz", "reports/index/concept_summary.tsv", "reports/index/concept_precision.tsv",
        "catalogs/concepts.tsv", "pipeline/index/build_concept_index.py", "docs/index/README_v30.md", "START_HERE.md",
        "CORPUS_LOCATIONS.md", "sources/checksums/v38_SHA256SUMS"]
paths = sorted({p for pat in pats for p in glob.glob(pat) if os.path.isfile(p)})
rows = open("MANIFEST.tsv", encoding="utf-8").read().rstrip("\n").split("\n")
idx = {r.split("\t")[0]: i for i, r in enumerate(rows)}
for p in paths:
    b = open(p, "rb").read(); line = f"{p}\t{hashlib.sha256(b).hexdigest()}\t{len(b)}\tv38\t{os.path.basename(p)}"
    if p in idx: rows[idx[p]] = line
    else: rows.append(line)
open("MANIFEST.tsv", "w", encoding="utf-8").write("\n".join(rows) + "\n")
print(len(paths), "files recorded in MANIFEST.tsv")
PY
