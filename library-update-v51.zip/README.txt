library-update-v51 (2026-10-02)
The first live Jalasa case recorded in the sijill: the seven heavens and the Mi'raj lecture.
- sijill/entries/2026-10-02-seven-heavens.jsonl: 134 draft entries (22 sayings, 22 authentications, 18 inferences,
  18 verdicts, 30 positions, 15 new voices, 6 open questions, topic, source event, study). All cited records resolve.
- docs/jalasa/STRESS_TEST.md: H4 and H5 are now must (sayings and authentications recorded); 4 new must cases
  (B13, B14, C8, C9) and 4 new goals (A8, B15, B16, B17) from this case. Rehearsed: must 55/55, goal 0/19.
The heart lecture's entries are NOT in this update: its findings were not available to this build.
To apply: upload this zip to the repo root, then run "Library update and search index" from the Actions tab.
