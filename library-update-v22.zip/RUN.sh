#!/bin/bash
# v22 collation: download pinned witnesses, collate the OCR works, write the confidence overlay.
set -euo pipefail
python3 pipeline/verify/ocr_quality.py --repo . > /dev/null
python3 pipeline/verify/collate.py --repo .
python3 - <<'PY'
import os, glob, hashlib
def sha(p):
    h = hashlib.sha256()
    with open(p, 'rb') as f:
        for c in iter(lambda: f.read(1 << 20), b''): h.update(c)
    return h.hexdigest()
new = sorted(glob.glob('sources/witnesses/*/*/*') + glob.glob('reports/collation/*') +
             ['catalogs/witnesses.tsv', 'pipeline/verify/collate.py', 'docs/verification/COLLATION.md'])
have = {l.split('\t')[0] for l in open('MANIFEST.tsv', encoding='utf-8')}
with open('MANIFEST.tsv', 'a', encoding='utf-8') as m, open('sources/checksums/v22_SHA256SUMS', 'w') as c:
    for p in new:
        h = sha(p); c.write(f'{h}  {p}\n')
        if p not in have: m.write(f'{p}\t{h}\t{os.path.getsize(p)}\tv22\t{os.path.basename(p)}\n')
row = ("| reports/collation/ | **Collation (v22):** OCR pages lined up against independent free witnesses "
       "(catalogs/witnesses.tsv; files in sources/witnesses/). confidence.tsv.gz is the per-page overlay "
       "(OCR score, best agreement, verification status, level: verified / corroborated / partial / divergent / "
       "unmatched / no_witness), keyed by record_id. See docs/verification/COLLATION.md. |\n")
L = open('CORPUS_LOCATIONS.md', encoding='utf-8').read().splitlines(keepends=True)
if not any('reports/collation/' in l for l in L):
    i = next(k for k, l in enumerate(L) if l.startswith('| catalogs/verification_log.tsv'))
    L.insert(i + 1, row); open('CORPUS_LOCATIONS.md', 'w', encoding='utf-8').writelines(L)
print('v22 collation applied')
PY
