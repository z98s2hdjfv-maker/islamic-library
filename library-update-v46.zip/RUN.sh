#!/bin/bash
# v46: put the eight collections of v45 into the hadith layer, rebuild parallels and narrator links over all 21,
# rejoin the critics' verdicts (al-Haythami now reaches all six of his sources), rebuild the sayings tables,
# bring the manifest up to date, then run the checks. Any failure stops the update before anything is committed.
set -e
python3 -c "import numpy" 2>/dev/null || pip install -q --break-system-packages numpy || pip install -q numpy
python3 pipeline/hadith/build_hadith_layer_extra.py --repo .
python3 pipeline/hadith/build_hadith_links.py --repo .
python3 pipeline/hadith/build_critic_grades.py --repo . all
python3 pipeline/hadith/build_sayings.py --repo .
python3 pipeline/repo/update_manifest.py --origin v46
python3 pipeline/hadith/test_authenticate.py
python3 pipeline/sijill/sijill.py --repo . all
