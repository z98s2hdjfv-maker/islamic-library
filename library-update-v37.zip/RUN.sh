#!/bin/bash
# v37: printed hadith numbers; collation levels for every OCR work (+2 new witnesses); best readings refreshed.
# Each stage warns instead of blocking the update.
python3 pipeline/hadith/edition_numbers.py --repo . || echo "::warning::edition numbers not added"
python3 pipeline/verify/collate.py --repo . --new-ocr || echo "::warning::new OCR works not collated"
python3 pipeline/verify/best_reading.py --repo . || echo "::warning::best readings not refreshed"
python3 pipeline/verify/collate.py --repo . --levels-only || echo "::warning::levels not recounted"
python3 pipeline/index/lookup.py --repo . --build-meta || echo "::warning::works_meta not refreshed"
python3 - <<'PY'
import glob, hashlib, os
pats = ["apparatus/hadith/0279Tirmidhi.Sunan.jsonl.gz", "apparatus/hadith/0256Bukhari.Sahih.jsonl.gz", "apparatus/hadith_numbers/*",
        "reports/collation/*", "apparatus/best_reading/*", "reports/best_reading/*", "reports/index/works_meta.tsv",
        "sources/witnesses/kalam.*/*/*", "catalogs/witnesses.tsv", "catalogs/edition_numbers_pins.json",
        "pipeline/hadith/edition_numbers.py", "pipeline/verify/collate.py", "pipeline/search/textsearch.py",
        "pipeline/search/build_index.py", "pipeline/search/search.py", "START_HERE.md", "CORPUS_LOCATIONS.md",
        "docs/hadith_layer/README.md", "docs/search/README.md", "sources/checksums/v37_SHA256SUMS"]
paths = sorted({p for pat in pats for p in glob.glob(pat) if os.path.isfile(p)})
rows = open("MANIFEST.tsv", encoding="utf-8").read().rstrip("\n").split("\n")
idx = {r.split("\t")[0]: i for i, r in enumerate(rows)}
for p in paths:
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for c in iter(lambda: f.read(1 << 20), b""): h.update(c)
    line = f"{p}\t{h.hexdigest()}\t{os.path.getsize(p)}\tv37\t{os.path.basename(p)}"
    if p in idx: rows[idx[p]] = line
    else: rows.append(line)
open("MANIFEST.tsv", "w", encoding="utf-8").write("\n".join(rows) + "\n")
print(len(paths), "files recorded in MANIFEST.tsv")
PY
