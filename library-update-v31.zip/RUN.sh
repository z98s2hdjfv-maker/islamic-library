#!/bin/bash
# v31: the nur and wilaya dossiers.
set -euo pipefail
python3 - <<'PY'
import os, hashlib
def sha(p):
    h = hashlib.sha256()
    with open(p, 'rb') as f:
        for c in iter(lambda: f.read(1 << 20), b''): h.update(c)
    return h.hexdigest()
new = ['docs/dossiers/nur.md', 'docs/dossiers/wilaya.md']
have = {l.split('\t')[0] for l in open('MANIFEST.tsv', encoding='utf-8')}
with open('MANIFEST.tsv', 'a', encoding='utf-8') as m, open('sources/checksums/v31_SHA256SUMS', 'w') as c:
    for p in new:
        h = sha(p); c.write(f'{h}  {p}\n')
        if p not in have: m.write(f'{p}\t{h}\t{os.path.getsize(p)}\tv31\t{os.path.basename(p)}\n')
L = open('CORPUS_LOCATIONS.md', encoding='utf-8').read().splitlines(keepends=True)
for k, l in enumerate(L):
    if l.startswith('| docs/dossiers/') and 'nur.md' not in l:
        L[k] = l.replace('asma.md (the Names)', 'asma.md (the Names), nur.md (the Muhammadan Light and Reality, v31), wilaya.md (sainthood and the hidden hierarchy, v31)')
open('CORPUS_LOCATIONS.md', 'w', encoding='utf-8').writelines(L)
print('v31 applied')
PY
