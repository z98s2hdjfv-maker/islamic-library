#!/bin/bash
# v27: Ibn Arabi's Kashf al-mana (names) and Tarjuman al-ashwaq from archive.org scans; refresh index and overlays.
set -euo pipefail
python3 pipeline/works/ingest_archive_works.py --repo . --build
python3 - <<'PY'
import sys; sys.path.insert(0, 'pipeline/repo'); import add_works_batch as a; a.build_index('.')
PY
python3 pipeline/verify/check_verifications.py --repo .
python3 pipeline/verify/ocr_quality.py --repo . > /dev/null
python3 pipeline/verify/collate.py --repo . > /dev/null
python3 - <<'PY'
import os, glob, hashlib
def sha(p):
    h = hashlib.sha256()
    with open(p, 'rb') as f:
        for c in iter(lambda: f.read(1 << 20), b''): h.update(c)
    return h.hexdigest()
new = sorted(['corpus/asma/0638IbnCarabi.KashfMacna.jsonl.gz', 'corpus/ibnarabi/0638IbnCarabi.TarjumanAshwaq.jsonl.gz'] +
             glob.glob('sources/archive/asma/*/*') + glob.glob('sources/archive/ibnarabi/*/*') +
             ['catalogs/archive_works.tsv', 'catalogs/archive_works_manifest.json', 'catalogs/secondary_literature.tsv',
              'pipeline/works/ingest_archive_works.py', 'docs/asma/README.md'])
have = {l.split('\t')[0] for l in open('MANIFEST.tsv', encoding='utf-8')}
with open('MANIFEST.tsv', 'a', encoding='utf-8') as m, open('sources/checksums/v27_SHA256SUMS', 'w') as c:
    for p in new:
        h = sha(p); c.write(f'{h}  {p}\n')
        if p not in have: m.write(f'{p}\t{h}\t{os.path.getsize(p)}\tv27\t{os.path.basename(p)}\n')
L = open('CORPUS_LOCATIONS.md', encoding='utf-8').read().splitlines(keepends=True)
add = (" **v27** adds Ibn Arabi's Kashf al-mana an sirr asma Allah al-husna (archive.org OCR, catalogs/archive_works.tsv); "
       "his Tarjuman al-ashwaq with Dhakhair al-alaq goes to corpus/ibnarabi/. |")
for k, l in enumerate(L):
    if l.startswith('| corpus/asma/') and 'v27' not in l:
        L[k] = l.rstrip('\n').rstrip().rstrip('|').rstrip() + add + '\n'
open('CORPUS_LOCATIONS.md', 'w', encoding='utf-8').writelines(L)
print('v27 applied')
PY
