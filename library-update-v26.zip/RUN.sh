#!/bin/bash
# v26 asma canon: 15 works on the Beautiful Names and on addressing God; the 99-names table; refresh overlays.
set -euo pipefail
python3 pipeline/works/ingest_asma_canon.py --repo . --build
python3 - <<'PY'
import sys; sys.path.insert(0, 'pipeline/repo'); import add_works_batch as a; a.build_index('.')
PY
python3 pipeline/asma/build_names_table.py --repo .
python3 pipeline/verify/ocr_quality.py --repo . > /dev/null
python3 pipeline/verify/collate.py --repo . > /dev/null
python3 - <<'PY'
import os, glob, hashlib
def sha(p):
    h = hashlib.sha256()
    with open(p, 'rb') as f:
        for c in iter(lambda: f.read(1 << 20), b''): h.update(c)
    return h.hexdigest()
new = sorted(glob.glob('corpus/asma/*') + glob.glob('sources/openiti/asma/*') + glob.glob('reports/asma/*') +
             ['catalogs/asma_canon.tsv', 'catalogs/asma_canon_pins.json', 'catalogs/asma_canon_manifest.json',
              'pipeline/works/ingest_asma_canon.py', 'pipeline/asma/build_names_table.py', 'docs/asma/README.md'])
have = {l.split('\t')[0] for l in open('MANIFEST.tsv', encoding='utf-8')}
with open('MANIFEST.tsv', 'a', encoding='utf-8') as m, open('sources/checksums/v26_SHA256SUMS', 'w') as c:
    for p in new:
        h = sha(p); c.write(f'{h}  {p}\n')
        if p not in have: m.write(f'{p}\t{h}\t{os.path.getsize(p)}\tv26\t{os.path.basename(p)}\n')
row = ("| corpus/asma/ | **Asma canon (v26):** 15 works from OpenITI on the Beautiful Names and on addressing God: "
       "the hadith base and its grading (Ibn Hajar, al-Bayhaqi), the grammarians (al-Zajjaj, al-Zajjaji, al-Khattabi), "
       "the commentaries (al-Ghazali's Maqsad, al-Qurtubi, al-Razi, Ibn Ata Allah on the name Allah) and the manuals of "
       "address (al-Hikam, Dalail al-khayrat, al-Nawawi's Adhkar, Ibn al-Qayyim, al-Jilani's Ghunya and Jala al-khatir). "
       "reports/asma/names.tsv joins the 99 names (al-Tirmidhi's list) to the Qur'an and the commentaries. "
       "**.jsonl.gz**; search with `--author asma`. See docs/asma/README.md. |\n")
L = open('CORPUS_LOCATIONS.md', encoding='utf-8').read().splitlines(keepends=True)
if not any('corpus/asma/' in l for l in L):
    i = next(k for k, l in enumerate(L) if l.startswith('| corpus/nur/'))
    L.insert(i + 1, row); open('CORPUS_LOCATIONS.md', 'w', encoding='utf-8').writelines(L)
print('v26 asma canon applied:', len(glob.glob('corpus/asma/*')), 'works')
PY
