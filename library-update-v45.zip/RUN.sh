#!/bin/bash
# v45 (includes v44): import the 54 works of the authentication canon from OpenITI at their pinned commits,
# rebuild the sayings tables, bring the manifest up to date, then run the checks.
# Any failure stops the update before anything is committed.
set -e
python3 pipeline/works/ingest_canon.py --repo . --canon authentication --build
python3 pipeline/hadith/build_sayings.py --repo .
python3 pipeline/repo/update_manifest.py --origin v45
python3 pipeline/hadith/test_authenticate.py
python3 pipeline/sijill/sijill.py --repo . all
