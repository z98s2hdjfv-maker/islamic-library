library-update-v53 (2026-10-03). Apply after v52. Upload to the repo root, then run "Library update and search index".

Sijill (507 entries after this update; all drafts until a scholar reviews them)
- 2026-10-03-divine-sayings.jsonl: the forty divine sayings case, 133 entries (40 sayings with their standing, 12
  inferences with verdicts, 14 positions, 6 open questions). Approved by Housam 2026-10-03.
- 2026-10-03-ether.jsonl: the ether and Malakut case, 99 entries (12 new sayings; the rope hadith, the measures and the
  ʿamaʾ hadith are linked, not entered again; 20 inferences with verdicts; Rumi's corrected position). Approved 2026-10-03.
- 2026-10-03-confirmations.jsonl: Housam confirms Dr. Umar Faruq Abd-Allah as the speaker of the heart lecture.
- sijill.py: an entry that "answers" an open question closes it in the view. New standing "strange" (gharib).

Hadith layer and tools
- al-Tirmidhi's layer: 131 hadith the v16 build had dropped are added (3,843 -> 3,974), among them the black spot on the
  heart, the rope, "He was in a cloud" and the second Pen hadith. No existing id changed. pipeline/hadith/fix_tirmidhi_layer.py.
  Not rebuilt for the new hadith: the critics' and modern grade tables, parallels and chains.
- authenticate.py: --brief (one short block per saying); checks the sijill first and shows the standing already recorded;
  flags a saying with no classical verdict in the library; "ibn" and "bn" match as one word.
- cite.py: hadith-layer ids and Mathnawi couplets resolve; --many resolves several ids in one call, in under a second.
- test_authenticate.py: 35 checks (4 new).

Indexes and Rumi
- catalogs/concepts.tsv: 8 new concepts (qalb, miraj, sidra, kursi, arsh, sab_samawat, malakut, awwal_makhluq); the
  concept index was rebuilt in full (76,664 rows) and now includes Rumi's works.
- catalogs/term_bridge.tsv: Arabic terms -> Rumi's Persian words. textsearch.py and the concept index use it, so
  "مرآة القلب" reaches آینه دل and "عالم الأمر" reaches Mathnawi 4:3692.
- START_HERE.md: the rule "never record a master as silent before searching his own language"; rows for Rumi and brief mode.
- docs/dossiers: rumi.md, heart.md, first_created.md (7 dossiers now).

Stress test: 74 of 74 must (was 57), 12 goals left (was 19). Goals met and made must: A7, A8, B10, B15, B16, C7, F3, K9.
Rehearsed on a clean copy of the repo at v52 before delivery.
