#!/bin/bash
# v42: exact pages (pages.py, cite.py; lookup/search/textsearch print true pages), corrected citations in the dossiers
# and the sijill, and al-Shattanawfi's Bahjat al-asrar with two witnesses. Each stage warns instead of blocking.
python3 pipeline/works/ingest_canon.py --repo . --canon bahja --build || echo "::warning::Bahjat al-asrar not built"
python3 pipeline/verify/collate.py --repo . --work jilani.0713Shattanawfi.BahjatAsrar || echo "::warning::Bahjat not collated"
python3 pipeline/verify/best_reading.py --repo . || echo "::warning::best readings not refreshed"
python3 pipeline/verify/collate.py --repo . --levels-only || echo "::warning::levels not recounted"
python3 pipeline/index/lookup.py --repo . --build-meta || echo "::warning::works_meta not refreshed"
python3 pipeline/index/build_verse_index.py --repo . || echo "::warning::verse index not rebuilt"
python3 pipeline/index/build_concept_index.py --repo . || echo "::warning::concept index not rebuilt"
python3 pipeline/sijill/sijill.py --repo . all || echo "::warning::sijill problems (see above)"
python3 - <<'PY'
import glob, hashlib, os
pats = ["corpus/jilani/0713Shattanawfi.BahjatAsrar*", "sources/archive/bahja/*/*", "sources/witnesses/jilani.0713*/*/*", "catalogs/bahja_canon*",
        "catalogs/witnesses.tsv", "catalogs/works_index.tsv", "reports/collation/*", "apparatus/best_reading/*", "reports/best_reading/*",
        "reports/index/*", "sijill/entries/*", "sijill/views/*", "pipeline/search/pages.py", "pipeline/search/cite.py",
        "pipeline/search/textsearch.py", "pipeline/search/search.py", "pipeline/index/lookup.py", "docs/dossiers/*",
        "docs/search/README.md", "START_HERE.md", "CORPUS_LOCATIONS.md", "sources/checksums/v42_SHA256SUMS"]
paths = sorted({p for pat in pats for p in glob.glob(pat) if os.path.isfile(p)})
rows = open("MANIFEST.tsv", encoding="utf-8").read().rstrip("\n").split("\n")
idx = {r.split("\t")[0]: i for i, r in enumerate(rows)}
for p in paths:
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for c in iter(lambda: f.read(1 << 20), b""): h.update(c)
    line = f"{p}\t{h.hexdigest()}\t{os.path.getsize(p)}\tv42\t{os.path.basename(p)}"
    if p in idx: rows[idx[p]] = line
    else: rows.append(line)
open("MANIFEST.tsv", "w", encoding="utf-8").write("\n".join(rows) + "\n")
print(len(paths), "files recorded in MANIFEST.tsv")
PY
