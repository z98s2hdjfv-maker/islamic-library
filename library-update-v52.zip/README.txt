library-update-v52 (2026-10-02). APPLY AFTER v51 (it uses voices that v51 adds; both zips can be uploaded together).
The heart lecture (al-Ghazali's five conditions of the heart) recorded in the sijill, from a fresh study.
- sijill/entries/2026-10-02-heart.jsonl: 80 draft entries (7 sayings, 7 authentications, 15 inferences, 15 verdicts,
  23 positions, 5 new voices, 5 open questions, topic, source event, study). All cited records resolve.
- docs/jalasa/STRESS_TEST.md: v51's version plus two must cases (C10, C11) and raised floors in section H.
To apply: upload this zip to the repo root, then run "Library update and search index" from the Actions tab.
