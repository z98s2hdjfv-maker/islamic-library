#!/usr/bin/env bash
# library-update-v52: the heart lecture recorded in the sijill. Apply after v51.
set -euo pipefail
bash pipeline/repo/after_update.sh v52
