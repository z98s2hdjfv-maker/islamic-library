#!/bin/bash
# v13: build the madhhab canon from pinned OpenITI files, rebuild works_index, verify, record in MANIFEST.
# Called by the workflow from the repo root as: bash /tmp/upd/RUN.sh /tmp/upd
set -euo pipefail
UPD="$1"
python3 pipeline/works/ingest_madhhab_canon.py --repo . --build
python3 -c "import sys; sys.path.insert(0,'pipeline/repo'); import add_works_batch as a; a.build_index('.')"
python3 - "$UPD/EXPECTED_CONTENT.sha256" <<'PY'
import gzip, hashlib, os, sys
bad = 0; rows = []
for line in open(sys.argv[1], encoding="utf-8"):
    h, p = line.rstrip("\n").split("  ", 1)
    b = open(p, "rb").read()
    c = gzip.decompress(b) if p.endswith(".gz") else b
    if hashlib.sha256(c).hexdigest() != h: print("MISMATCH", p); bad += 1
    rows.append("\t".join([p, hashlib.sha256(b).hexdigest(), str(len(b)), "v13", os.path.basename(p)]))
if bad: sys.exit(f"{bad} files differ from the reference build")
with open("MANIFEST.tsv", "a", encoding="utf-8") as m: m.write("\n".join(rows) + "\n")
print("verified", len(rows), "files against the reference build")
PY
