#!/bin/bash
# v41: the sijill (record of the digital Jalasa): validate the entries and generate the views; multi-phrase textsearch;
# START_HERE (working economically, recording findings); fitra dossier. Never blocks the update.
python3 pipeline/sijill/sijill.py --repo . all || echo "::warning::sijill validation found problems (see above); views written anyway"
python3 - <<'PY'
import glob, hashlib, os
pats = ["sijill/registry/*", "sijill/entries/*", "sijill/views/*", "pipeline/sijill/sijill.py", "pipeline/search/textsearch.py",
        "docs/sijill/README.md", "docs/dossiers/fitra.md", "START_HERE.md", "CORPUS_LOCATIONS.md", "sources/checksums/v41_SHA256SUMS"]
paths = sorted({p for pat in pats for p in glob.glob(pat) if os.path.isfile(p)})
rows = open("MANIFEST.tsv", encoding="utf-8").read().rstrip("\n").split("\n")
idx = {r.split("\t")[0]: i for i, r in enumerate(rows)}
for p in paths:
    b = open(p, "rb").read(); line = f"{p}\t{hashlib.sha256(b).hexdigest()}\t{len(b)}\tv41\t{os.path.basename(p)}"
    if p in idx: rows[idx[p]] = line
    else: rows.append(line)
open("MANIFEST.tsv", "w", encoding="utf-8").write("\n".join(rows) + "\n")
print(len(paths), "files recorded in MANIFEST.tsv")
PY
