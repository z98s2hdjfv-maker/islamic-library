#!/bin/bash
# v28: Knysh's Risala translation as a reference (owned), with a chapter concordance to the Arabic Risala.
set -euo pipefail
python3 pipeline/verify/check_verifications.py --repo .
python3 - <<'PY'
import os, hashlib
def sha(p):
    h = hashlib.sha256()
    with open(p, 'rb') as f:
        for c in iter(lambda: f.read(1 << 20), b''): h.update(c)
    return h.hexdigest()
new = ['catalogs/secondary_literature.tsv', 'reports/concordance/knysh_risala.tsv',
       'pipeline/verify/build_knysh_concordance.py', 'docs/verification/KNYSH_CONCORDANCE.md']
have = {l.split('\t')[0] for l in open('MANIFEST.tsv', encoding='utf-8')}
with open('MANIFEST.tsv', 'a', encoding='utf-8') as m, open('sources/checksums/v28_SHA256SUMS', 'w') as c:
    for p in new:
        h = sha(p); c.write(f'{h}  {p}\n')
        if p not in have: m.write(f'{p}\t{h}\t{os.path.getsize(p)}\tv28\t{os.path.basename(p)}\n')
L = open('CORPUS_LOCATIONS.md', encoding='utf-8').read().splitlines(keepends=True)
add = " **v28** adds reports/concordance/knysh_risala.tsv (Knysh's Risala translation to our Arabic Risala; see docs/verification/KNYSH_CONCORDANCE.md). |"
for k, l in enumerate(L):
    if l.startswith('| catalogs/manuscripts.tsv') and 'v28' not in l:
        L[k] = l.rstrip('\n').rstrip().rstrip('|').rstrip() + add + '\n'
open('CORPUS_LOCATIONS.md', 'w', encoding='utf-8').writelines(L)
print('v28 applied')
PY
