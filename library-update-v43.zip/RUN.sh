#!/bin/bash
# v43: run the checks; a failure stops the update before anything is committed.
set -e
python3 pipeline/hadith/test_authenticate.py
python3 pipeline/sijill/sijill.py --repo . all
