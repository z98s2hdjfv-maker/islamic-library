#!/bin/bash
# v35: build the grading, afterlife and modern canons from pinned sources, join al-Dhahabi's verdicts,
# refresh citation data and the verse/concept indexes. Each stage warns instead of blocking the update.
ok=1
for c in grading afterlife modern; do
  python3 pipeline/works/ingest_canon.py --repo . --canon $c --build || { echo "::warning::canon $c failed"; ok=0; }
done
if [ -f corpus/grading/0405HakimNaysaburi.Mustadrak.jsonl.gz ]; then
  python3 pipeline/hadith/add_dhahabi_talkhis.py --repo . || echo "::warning::al-Dhahabi join failed"
fi
python3 pipeline/index/lookup.py --repo . --build-meta || echo "::warning::works_meta not refreshed"
python3 pipeline/index/build_verse_index.py --repo . || echo "::warning::verse index not rebuilt"
python3 pipeline/index/build_concept_index.py --repo . || echo "::warning::concept index not rebuilt"
python3 - <<'PY'
import glob, hashlib, os
pats = ["corpus/grading/*", "corpus/afterlife/*", "corpus/modern/*", "corpus/tafsir/1270ShihabDinAlusi.RuhMacani.jsonl.gz",
        "sources/openiti/grading/*", "sources/openiti/afterlife/*", "sources/openiti/modern/*",
        "sources/archive/afterlife/*/*", "sources/archive/modern/*/*", "apparatus/hadith_grades/*",
        "catalogs/*_canon_manifest.json", "catalogs/works_index.tsv", "reports/index/*",
        "START_HERE.md", "docs/canons/*", "docs/dossiers/*", "docs/hadith_layer/README.md", "catalogs/*_canon.tsv",
        "catalogs/*_canon_pins.json", "pipeline/works/ingest_canon.py", "pipeline/hadith/add_dhahabi_talkhis.py",
        "pipeline/search/build_index.py", "pipeline/index/build_verse_index.py", "pipeline/index/build_concept_index.py",
        "sources/checksums/v35_SHA256SUMS"]
paths = sorted({p for pat in pats for p in glob.glob(pat) if os.path.isfile(p)})
rows = open("MANIFEST.tsv", encoding="utf-8").read().rstrip("\n").split("\n")
idx = {r.split("\t")[0]: i for i, r in enumerate(rows)}
for p in paths:
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for c in iter(lambda: f.read(1 << 20), b""): h.update(c)
    line = f"{p}\t{h.hexdigest()}\t{os.path.getsize(p)}\tv35\t{os.path.basename(p)}"
    if p in idx: rows[idx[p]] = line
    else: rows.append(line)
open("MANIFEST.tsv", "w", encoding="utf-8").write("\n".join(rows) + "\n")
print(len(paths), "files recorded in MANIFEST.tsv")
PY
[ $ok = 1 ] || echo "::warning::v35 applied with warnings (see above)"
