#!/usr/bin/env bash
# library-update-v50: the Jalasa stress test. The checks run it; a failed must stops the update.
set -euo pipefail
bash pipeline/repo/after_update.sh v50
