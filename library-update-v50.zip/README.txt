library-update-v50: the Jalasa stress test (docs/jalasa/STRESS_TEST.md + pipeline/jalasa/stress_test.py).
Upload to the repo root and run the "Library update and search index" workflow.
