library-update-v54 (2026-10-03). APPLY AFTER v53 (both zips can be uploaded together; the workflow applies them in order).

The Mathnawi by story, and layered readings in the sijill.
- apparatus/mathnawi/sections.tsv: Rumi's own prose heading for each of the 972 sections of the six books, with the
  couplet range (from the pinned Ganjoor commit; pipeline/mathnawi/build_sections.py). Machine-written summaries in the
  source are not imported.
- apparatus/mathnawi/stories_book1.tsv: the 20 stories of Book 1 with their inset tales (Claude's reading of the
  headings; unverified). Books 2 to 6 have the headings only.
- pipeline/mathnawi/story.py: a couplet with Rumi's heading, its story, who speaks and the readings recorded for it.
- Sijill: new types "passage" (with the voice that speaks in it) and "reading" (with its layer: plain sense, the
  author's own stated meaning, a commentator, a reader, Claude's analysis), relations "reads" and "part_of", a layers
  registry, validation, and a new view sijill/views/readings.md.
- sijill/entries/2026-10-03-parrot-readings.jsonl: the grocer and the parrot (Mathnawi 1:247-323), sections 1 to 8:
  11 passages and 33 readings (6 of Rumi's own stated meanings, 12 of Housam's readings in his words, 11 analyses and
  4 plain-sense summaries by Claude). 556 entries in all. All drafts until a scholar reviews them.
- START_HERE.md section 4c: a story is quoted with its voice and its layer. docs/mathnawi/STORIES.md. Rumi dossier updated.
- Stress test: new section L (stories, voice and layers): 5 must, 3 goals. 79 of 79 must after this update.
Rehearsed on a clean copy of the repo at v52, after v53.
