#!/usr/bin/env bash
# library-update-v54: the Mathnawi by story; passages and readings in the sijill. Apply after v53.
set -euo pipefail
bash pipeline/repo/after_update.sh v54
