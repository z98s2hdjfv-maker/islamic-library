#!/usr/bin/env bash
# library-update-v48: fixes from the audit of v47; the files are data already built.
set -euo pipefail
python3 pipeline/repo/update_manifest.py --origin v48
