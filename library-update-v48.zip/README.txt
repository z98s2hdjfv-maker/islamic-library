library-update-v48: fixes from the audit of v47 and a repo tidy.
Upload to the repo root and run the "Library update and search index" workflow.
What changed: docs/hadith_layer/V48_FIXES.md
