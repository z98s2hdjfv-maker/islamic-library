#!/usr/bin/env bash
# v16: build the hadith layer (apparatus/hadith/) from corpus/hadith/, record it in MANIFEST.tsv.
set -euo pipefail
python3 pipeline/hadith/build_hadith_layer.py --repo .
python3 - <<'PY'
import glob, hashlib, os
files = sorted(glob.glob("apparatus/hadith/*.jsonl.gz")) + ["catalogs/hadith_layer_summary.json"]
with open("MANIFEST.tsv", "a", encoding="utf-8") as m:
    for f in files:
        m.write("\t".join([f, hashlib.sha256(open(f, "rb").read()).hexdigest(), str(os.path.getsize(f)), "v16", os.path.basename(f)]) + "\n")
p = "CORPUS_LOCATIONS.md"; s = open(p, encoding="utf-8").read()
add = ("\n## v16: hadith layer\n"
       "apparatus/hadith/<collection>.jsonl.gz: one record per hadith (id urn:hadith:<collection>:<number>) with isnad, matn, "
       "narrator, caliph, grades found in the sources, and compiler comments. Numbering, method and limits: docs/hadith_layer/README.md. "
       "Summary: catalogs/hadith_layer_summary.json.\n")
if "## v16:" not in s: open(p, "w", encoding="utf-8").write(s.rstrip("\n") + "\n" + add)
PY
echo "v16 applied"
