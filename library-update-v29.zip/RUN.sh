#!/bin/bash
# v29: verse index for the commentaries and Sufi collections, works metadata, one-command lookup.
set -euo pipefail
python3 pipeline/index/build_verse_index.py --repo .
python3 pipeline/index/lookup.py --repo . --build-meta
python3 pipeline/index/lookup.py --repo . --verse 2:31 --per-work 0 > /tmp/v29_check.txt; head -1 /tmp/v29_check.txt
python3 - <<'PY'
import os, glob, hashlib
def sha(p):
    h = hashlib.sha256()
    with open(p, 'rb') as f:
        for c in iter(lambda: f.read(1 << 20), b''): h.update(c)
    return h.hexdigest()
new = sorted(glob.glob('reports/index/*') + ['pipeline/index/build_verse_index.py', 'pipeline/index/lookup.py', 'docs/index/README.md'])
have = {l.split('\t')[0] for l in open('MANIFEST.tsv', encoding='utf-8')}
with open('MANIFEST.tsv', 'a', encoding='utf-8') as m, open('sources/checksums/v29_SHA256SUMS', 'w') as c:
    for p in new:
        h = sha(p); c.write(f'{h}  {p}\n')
        if p not in have: m.write(f'{p}\t{h}\t{os.path.getsize(p)}\tv29\t{os.path.basename(p)}\n')
row = ("| reports/index/ | **Verse index and lookup (v29):** every commentary passage tagged with its verse and every quotation "
       "of a verse in the Sufi collections (verse_index.tsv.gz); per-work citation data (works_meta.tsv). "
       "`python3 pipeline/index/lookup.py --repo . --verse 2:31` returns all works on a verse, oldest first, cited and graded. "
       "See docs/index/README.md. |\n")
L = open('CORPUS_LOCATIONS.md', encoding='utf-8').read().splitlines(keepends=True)
if not any(l.startswith('| reports/index/') for l in L):
    i = next(k for k, l in enumerate(L) if l.startswith('| catalogs/manuscripts.tsv'))
    L.insert(i + 1, row); open('CORPUS_LOCATIONS.md', 'w', encoding='utf-8').writelines(L)
print('v29 applied')
PY
