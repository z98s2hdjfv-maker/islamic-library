#!/bin/bash
# v33: build the best readings from the cached witnesses; never blocks the update if it fails
if python3 pipeline/verify/best_reading.py --repo .; then
  python3 - <<'PY'
import hashlib, glob, os
rows = open("MANIFEST.tsv", encoding="utf-8").read().rstrip("\n").split("\n")
keep = [r for r in rows if not r.startswith(("apparatus/best_reading/", "reports/best_reading/"))]
for p in sorted(glob.glob("apparatus/best_reading/*") + glob.glob("reports/best_reading/*")):
    b = open(p, "rb").read()
    keep.append(f"{p}\t{hashlib.sha256(b).hexdigest()}\t{len(b)}\tv33\t{os.path.basename(p)}")
open("MANIFEST.tsv", "w", encoding="utf-8").write("\n".join(keep) + "\n")
PY
else
  echo "::warning::best_reading.py failed; the rest of v33 is applied without readings"
fi
