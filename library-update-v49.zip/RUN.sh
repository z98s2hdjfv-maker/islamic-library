#!/usr/bin/env bash
# library-update-v49: upkeep. Runs the checks every update now runs; if one fails, nothing is committed.
set -euo pipefail
bash pipeline/repo/after_update.sh v49
