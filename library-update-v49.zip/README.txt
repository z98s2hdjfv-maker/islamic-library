library-update-v49: tests inside every update, a faster authenticate command, README up to date.
Upload to the repo root and run the "Library update and search index" workflow.
