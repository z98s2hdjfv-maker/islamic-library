#!/usr/bin/env bash
# v14: import the Companions and caliphs canon from OpenITI (pinned; sha256-checked), then refresh works_index.
set -euo pipefail
python3 pipeline/works/ingest_companions_canon.py --repo . --build
python3 -c "import sys; sys.path.insert(0, 'pipeline/repo'); from add_works_batch import build_index; build_index('.')"
python3 - <<'PY'
p = "CORPUS_LOCATIONS.md"; s = open(p, encoding="utf-8").read()
add = ("\n## v14: Companions and caliphs canon\n"
       "58 OpenITI works in topic folders under corpus/: athar, consensus, judging, sira, sahaba, history, rijal, "
       "sufi_manuals, tafsir_sufi, tafsir_ahkam, kalam, critics, alawi, lugha. List, pins and gaps: docs/companions/README.md. "
       "Nahj al-balagha is flagged doubtful.\n")
if "## v14:" not in s: open(p, "w", encoding="utf-8").write(s.rstrip("\n") + "\n" + add)
PY
echo "v14 applied"
