#!/bin/bash
# v30: concept index, concept lookup, corrected works metadata, first dossier (the Names).
set -euo pipefail
python3 pipeline/index/build_concept_index.py --repo .
python3 pipeline/index/lookup.py --repo . --build-meta
python3 pipeline/index/lookup.py --repo . --concept kawn_jami --work nur --per-work 0 > /tmp/v30_check.txt; head -1 /tmp/v30_check.txt
python3 - <<'PY'
import os, hashlib
def sha(p):
    h = hashlib.sha256()
    with open(p, 'rb') as f:
        for c in iter(lambda: f.read(1 << 20), b''): h.update(c)
    return h.hexdigest()
new = ['catalogs/concepts.tsv', 'reports/index/concept_index.tsv.gz', 'reports/index/concept_summary.tsv',
       'reports/index/works_meta.tsv', 'pipeline/index/build_concept_index.py', 'pipeline/index/lookup.py',
       'docs/index/README_v30.md', 'docs/dossiers/asma.md']
have = {l.split('\t')[0] for l in open('MANIFEST.tsv', encoding='utf-8')}
with open('MANIFEST.tsv', 'a', encoding='utf-8') as m, open('sources/checksums/v30_SHA256SUMS', 'w') as c:
    for p in new:
        h = sha(p); c.write(f'{h}  {p}\n')
        if p not in have: m.write(f'{p}\t{h}\t{os.path.getsize(p)}\tv30\t{os.path.basename(p)}\n')
row = ("| docs/dossiers/ | **Dossiers (v30):** one cited brief per topic, to load into the Claude Project so a new chat starts "
       "from it: asma.md (the Names). Concept index: catalogs/concepts.tsv, reports/index/concept_index.tsv.gz, "
       "`lookup.py --concept qutb`. See docs/index/README_v30.md. |\n")
L = open('CORPUS_LOCATIONS.md', encoding='utf-8').read().splitlines(keepends=True)
if not any(l.startswith('| docs/dossiers/') for l in L):
    i = next(k for k, l in enumerate(L) if l.startswith('| reports/index/'))
    L.insert(i + 1, row); open('CORPUS_LOCATIONS.md', 'w', encoding='utf-8').writelines(L)
print('v30 applied')
PY
