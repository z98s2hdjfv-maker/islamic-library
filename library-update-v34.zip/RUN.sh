#!/bin/bash
# v34: recount the collation levels with independent witnesses only; refresh the per-work citation data.
# Needs reports/best_reading/witness_independence.tsv (written by v33). Never blocks the update.
if python3 pipeline/verify/collate.py --repo . --levels-only && python3 pipeline/index/lookup.py --repo . --build-meta; then
  python3 - <<'PY'
import hashlib, os
paths = ["reports/collation/confidence.tsv.gz", "reports/collation/confidence_summary.tsv", "reports/index/works_meta.tsv",
         "pipeline/verify/collate.py", "docs/dossiers/asma.md", "docs/best_reading/README.md", "sources/checksums/v34_SHA256SUMS"]
rows = open("MANIFEST.tsv", encoding="utf-8").read().rstrip("\n").split("\n")
idx = {r.split("\t")[0]: i for i, r in enumerate(rows)}
for p in paths:
    b = open(p, "rb").read(); line = f"{p}\t{hashlib.sha256(b).hexdigest()}\t{len(b)}\tv34\t{os.path.basename(p)}"
    if p in idx: rows[idx[p]] = line
    else: rows.append(line)
open("MANIFEST.tsv", "w", encoding="utf-8").write("\n".join(rows) + "\n")
PY
else
  echo "::warning::v34 level recount failed; levels left as they were"
fi
