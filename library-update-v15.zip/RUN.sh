#!/usr/bin/env bash
# v15: import the Quran (Tanzil), the main hadith collections and tafsirs from OpenITI (pinned; sha256-checked),
# add Tanzil's Uthmani text if tanzil.net is reachable, then refresh works_index.
set -euo pipefail
python3 pipeline/works/ingest_quran_hadith.py --repo . --build --uthmani
python3 -c "import sys; sys.path.insert(0, 'pipeline/repo'); from add_works_batch import build_index; build_index('.')"
python3 - <<'PY'
p = "CORPUS_LOCATIONS.md"; s = open(p, encoding="utf-8").read()
add = ("\n## v15: Quran, hadith and tafsir\n"
       "corpus/quran/ (6,236 verses, id urn:quran:S:A, Tanzil text, CC BY 3.0), corpus/hadith/ (16 collections), "
       "corpus/tafsir/ (9 tafsirs). Details and gaps: docs/quran_hadith/README.md.\n")
if "## v15:" not in s: open(p, "w", encoding="utf-8").write(s.rstrip("\n") + "\n" + add)
PY
echo "v15 applied"
