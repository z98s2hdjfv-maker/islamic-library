#!/bin/bash
# v39: textsearch.py fixes and the dossiers with v38 concept counts; record them in MANIFEST.tsv.
python3 - <<'PY'
import glob, hashlib, os
paths = ["pipeline/search/textsearch.py", "docs/search/README.md", "docs/dossiers/asma.md", "docs/dossiers/nur.md",
         "docs/dossiers/wilaya.md", "sources/checksums/v39_SHA256SUMS"]
rows = open("MANIFEST.tsv", encoding="utf-8").read().rstrip("\n").split("\n")
idx = {r.split("\t")[0]: i for i, r in enumerate(rows)}
for p in paths:
    b = open(p, "rb").read(); line = f"{p}\t{hashlib.sha256(b).hexdigest()}\t{len(b)}\tv39\t{os.path.basename(p)}"
    if p in idx: rows[idx[p]] = line
    else: rows.append(line)
open("MANIFEST.tsv", "w", encoding="utf-8").write("\n".join(rows) + "\n")
print(len(paths), "files recorded in MANIFEST.tsv")
PY
