#!/bin/bash
# v40: the fitra canon (Ibn Taymiyya's Darʾ, Ibn ʿAbd al-Barr's Tamhid, Ibn al-Qayyim's Shifaʾ al-ʿalil);
# refresh citation data and the verse/concept indexes (now with the fitra folder and concept). Warns, never blocks.
python3 pipeline/works/ingest_canon.py --repo . --canon fitra --build || echo "::warning::fitra canon failed"
python3 pipeline/index/lookup.py --repo . --build-meta || echo "::warning::works_meta not refreshed"
python3 pipeline/index/build_verse_index.py --repo . || echo "::warning::verse index not rebuilt"
python3 pipeline/index/build_concept_index.py --repo . || echo "::warning::concept index not rebuilt"
python3 - <<'PY'
import glob, hashlib, os
pats = ["corpus/fitra/*", "sources/openiti/fitra/*", "catalogs/fitra_canon*", "catalogs/concepts.tsv", "catalogs/works_index.tsv",
        "reports/index/*", "pipeline/index/build_verse_index.py", "pipeline/index/build_concept_index.py", "pipeline/index/lookup.py", "docs/canons/README.md",
        "START_HERE.md", "CORPUS_LOCATIONS.md", "sources/checksums/v40_SHA256SUMS"]
paths = sorted({p for pat in pats for p in glob.glob(pat) if os.path.isfile(p)})
rows = open("MANIFEST.tsv", encoding="utf-8").read().rstrip("\n").split("\n")
idx = {r.split("\t")[0]: i for i, r in enumerate(rows)}
for p in paths:
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for c in iter(lambda: f.read(1 << 20), b""): h.update(c)
    line = f"{p}\t{h.hexdigest()}\t{os.path.getsize(p)}\tv40\t{os.path.basename(p)}"
    if p in idx: rows[idx[p]] = line
    else: rows.append(line)
open("MANIFEST.tsv", "w", encoding="utf-8").write("\n".join(rows) + "\n")
print(len(paths), "files recorded in MANIFEST.tsv")
PY
