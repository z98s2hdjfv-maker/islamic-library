#!/bin/bash
# v18 wilaya canon: download the pinned OpenITI files (sha256-checked), build corpus/wilaya/,
# rebuild catalogs/works_index.tsv, record checksums and MANIFEST rows, add a CORPUS_LOCATIONS row.
set -euo pipefail
python3 pipeline/works/ingest_wilaya_canon.py --repo . --build
python3 - <<'PY'
import sys, os, glob, hashlib
sys.path.insert(0, 'pipeline/repo'); import add_works_batch as a
a.build_index('.')
def sha(p):
    h = hashlib.sha256()
    with open(p, 'rb') as f:
        for c in iter(lambda: f.read(1 << 20), b''): h.update(c)
    return h.hexdigest()
new = sorted(glob.glob('corpus/wilaya/*') + glob.glob('sources/openiti/wilaya/*') +
             ['catalogs/wilaya_canon.tsv', 'catalogs/wilaya_canon_pins.json', 'catalogs/wilaya_canon_manifest.json',
              'pipeline/works/ingest_wilaya_canon.py', 'docs/wilaya/README.md'])
have = {l.split('\t')[0] for l in open('MANIFEST.tsv', encoding='utf-8')}
with open('MANIFEST.tsv', 'a', encoding='utf-8') as m, open('sources/checksums/v18_SHA256SUMS', 'w') as c:
    for p in new:
        h = sha(p); c.write(f'{h}  {p}\n')
        if p not in have: m.write(f'{p}\t{h}\t{os.path.getsize(p)}\tv18\t{os.path.basename(p)}\n')
row = ("| corpus/wilaya/ | **Wilaya canon (v18):** 26 works from OpenITI on the hidden hierarchy of saints (quṭb, awtād, abdāl, "
       "nujabāʾ, nuqabāʾ, afrād): theorists (al-Ḥakīm al-Tirmidhī, Ibn ʿAṭāʾ Allāh), transmitters (Tārīkh Baghdād, Tārīkh Dimashq), "
       "ḥadīth critics and defenders (Ibn al-Jawzī, Ibn al-Qayyim, al-Suyūṭī, al-Sakhāwī, al-Qārī, al-Kattānī), theological critics "
       "(Ibn Taymiyya's Furqān, Ibn Khaldūn), creed and hagiography. Pinned in catalogs/wilaya_canon_pins.json; list in "
       "catalogs/wilaya_canon.tsv (scholar review pending). **.jsonl.gz**; search with `--author wilaya`. See docs/wilaya/README.md. |\n")
L = open('CORPUS_LOCATIONS.md', encoding='utf-8').read().splitlines(keepends=True)
if not any('corpus/wilaya/' in l for l in L):
    i = next(k for k, l in enumerate(L) if l.startswith('| corpus/hanafi/'))
    L.insert(i + 1, row)
    open('CORPUS_LOCATIONS.md', 'w', encoding='utf-8').writelines(L)
print('v18 wilaya canon applied:', len(glob.glob('corpus/wilaya/*')), 'works')
PY
