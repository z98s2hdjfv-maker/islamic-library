#!/usr/bin/env bash
# v17: hadith parallels + narrator links (Taqrib), then record outputs. The search index is rebuilt by the
# workflow's next step with the new hadith tables (pipeline/search/build_index.py, updated in this zip).
set -euo pipefail
python3 -c "import numpy" 2>/dev/null || python3 -m pip install --quiet numpy 2>/dev/null || python3 -m pip install --quiet --break-system-packages numpy
python3 pipeline/hadith/build_hadith_links.py --repo .
python3 - <<'PY'
import glob, hashlib, os
files = sorted(glob.glob("apparatus/hadith_links/*.gz")) + ["apparatus/rijal/taqrib_index.tsv.gz", "catalogs/hadith_links_summary.json"]
with open("MANIFEST.tsv", "a", encoding="utf-8") as m:
    for f in files:
        m.write("\t".join([f, hashlib.sha256(open(f, "rb").read()).hexdigest(), str(os.path.getsize(f)), "v17", os.path.basename(f)]) + "\n")
p = "CORPUS_LOCATIONS.md"; s = open(p, encoding="utf-8").read()
add = ("\n## v17: hadith links and search\n"
       "apparatus/hadith_links/ (parallels across collections; chains with narrators linked to Ibn Hajar's Taqrib), "
       "apparatus/rijal/taqrib_index.tsv.gz, catalogs/narrator_aliases.tsv. The search index has hadith tables and "
       "filters (--caliph, --narrator, --graded, --agreed, --parallels). Details: docs/hadith_links/README.md.\n")
if "## v17:" not in s: open(p, "w", encoding="utf-8").write(s.rstrip("\n") + "\n" + add)
p = "docs/search/README.md"; s = open(p, encoding="utf-8").read()
if "## Hadith filters" not in s:
    open(p, "w", encoding="utf-8").write(s.rstrip("\n") + "\n\n## Hadith filters (v17)\nSee docs/hadith_links/README.md: "
        "--hadith-only, --caliph, --narrator, --graded, --agreed, --max-weakest-rank, --parallels.\n")
PY
echo "v17 applied"
