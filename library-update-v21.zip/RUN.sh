#!/bin/bash
# v21 verification layer: secondary literature catalog, verification log, OCR triage reports.
set -euo pipefail
python3 pipeline/verify/ocr_quality.py --repo . > /dev/null
python3 pipeline/verify/check_verifications.py --repo .
python3 - <<'PY'
import os, hashlib
def sha(p):
    h = hashlib.sha256()
    with open(p, 'rb') as f:
        for c in iter(lambda: f.read(1 << 20), b''): h.update(c)
    return h.hexdigest()
new = ['catalogs/secondary_literature.tsv', 'catalogs/verification_log.tsv', 'docs/verification/README.md',
       'pipeline/verify/ocr_quality.py', 'pipeline/verify/check_verifications.py',
       'reports/ocr_quality_works.tsv', 'reports/ocr_quality_worst.tsv', 'reports/verification_summary.tsv']
have = {l.split('\t')[0] for l in open('MANIFEST.tsv', encoding='utf-8')}
with open('MANIFEST.tsv', 'a', encoding='utf-8') as m, open('sources/checksums/v21_SHA256SUMS', 'w') as c:
    for p in new:
        h = sha(p); c.write(f'{h}  {p}\n')
        if p not in have: m.write(f'{p}\t{h}\t{os.path.getsize(p)}\tv21\t{os.path.basename(p)}\n')
row = ("| catalogs/verification_log.tsv | **Verification layer (v21):** checks of uncorrected OCR against the scan or a printed "
       "edition, recorded without editing the corpus. References in catalogs/secondary_literature.tsv; triage of the 21 OCR "
       "works in reports/ocr_quality_*.tsv; coverage in reports/verification_summary.tsv. "
       "See docs/verification/README.md. |\n")
L = open('CORPUS_LOCATIONS.md', encoding='utf-8').read().splitlines(keepends=True)
if not any('catalogs/verification_log.tsv' in l for l in L):
    i = next(k for k, l in enumerate(L) if l.startswith('| corpus/nur/'))
    L.insert(i + 1, row); open('CORPUS_LOCATIONS.md', 'w', encoding='utf-8').writelines(L)
print('v21 verification layer applied')
PY
