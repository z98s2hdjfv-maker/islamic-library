#!/bin/bash
# v19 nur canon: download the pinned OpenITI files (sha256-checked), build corpus/nur/,
# rebuild catalogs/works_index.tsv, record checksums and MANIFEST rows, add a CORPUS_LOCATIONS row.
set -euo pipefail
python3 pipeline/works/ingest_nur_canon.py --repo . --build
python3 - <<'PY'
import sys, os, glob, hashlib
sys.path.insert(0, 'pipeline/repo'); import add_works_batch as a
a.build_index('.')
def sha(p):
    h = hashlib.sha256()
    with open(p, 'rb') as f:
        for c in iter(lambda: f.read(1 << 20), b''): h.update(c)
    return h.hexdigest()
new = sorted(glob.glob('corpus/nur/*') + glob.glob('sources/openiti/nur/*') +
             ['catalogs/nur_canon.tsv', 'catalogs/nur_canon_pins.json', 'catalogs/nur_canon_manifest.json',
              'pipeline/works/ingest_nur_canon.py', 'docs/nur/README.md'])
have = {l.split('\t')[0] for l in open('MANIFEST.tsv', encoding='utf-8')}
with open('MANIFEST.tsv', 'a', encoding='utf-8') as m, open('sources/checksums/v19_SHA256SUMS', 'w') as c:
    for p in new:
        h = sha(p); c.write(f'{h}  {p}\n')
        if p not in have: m.write(f'{p}\t{h}\t{os.path.getsize(p)}\tv19\t{os.path.basename(p)}\n')
row = ("| corpus/nur/ | **Nur canon (v19):** 17 works from OpenITI on the Muhammadan Light and Reality and the philosophy of light, "
       "intellect and prime matter behind Futuhat ch. 6: Akbarian theorists (Ibn Sabin, al-Qunawi, al-Fanari, al-Jili, Bursevi's Ruh al-bayan), "
       "al-Ghazali's Mishkat, the poets (Ibn al-Farid, al-Busiri), sira sources (al-Qastallani's Mawahib, al-Zurqani, al-Suyuti's Khasais, "
       "Abu Nuaym's Dalail) and the philosophers (Ikhwan al-Safa, Ibn Sina's Shifa, al-Ghazali's Tahafut). Pinned in catalogs/nur_canon_pins.json; "
       "list in catalogs/nur_canon.tsv (scholar review pending). **.jsonl.gz**; search with `--author nur`. See docs/nur/README.md. |\n")
L = open('CORPUS_LOCATIONS.md', encoding='utf-8').read().splitlines(keepends=True)
if not any('corpus/nur/' in l for l in L):
    i = next(k for k, l in enumerate(L) if l.startswith('| corpus/wilaya/'))
    L.insert(i + 1, row)
    open('CORPUS_LOCATIONS.md', 'w', encoding='utf-8').writelines(L)
print('v19 nur canon applied:', len(glob.glob('corpus/nur/*')), 'works')
PY
