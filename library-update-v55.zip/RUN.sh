#!/usr/bin/env bash
# library-update-v55: the grocer and the parrot read to its end; the fifth case (the karamat of al-Jilani);
# the al-Jilani dossier; textsearch --work with several names; the whisperer in the term bridge; stress test rows.
# No corpus or apparatus file changes. Runs the standard checks; a failure stops the update before the commit.
set -euo pipefail
bash pipeline/repo/after_update.sh v55
