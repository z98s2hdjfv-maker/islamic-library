#!/bin/bash
# v23: second round of witnesses; re-run the collation overlay.
set -euo pipefail
python3 pipeline/verify/collate.py --repo .
python3 - <<'PY'
import os, glob, hashlib
def sha(p):
    h = hashlib.sha256()
    with open(p, 'rb') as f:
        for c in iter(lambda: f.read(1 << 20), b''): h.update(c)
    return h.hexdigest()
new = sorted(glob.glob('sources/witnesses/*/*/*') + glob.glob('reports/collation/*') +
             ['catalogs/witnesses.tsv', 'docs/verification/COLLATION.md'])
have = {l.split('\t')[0] for l in open('MANIFEST.tsv', encoding='utf-8')}
with open('MANIFEST.tsv', 'a', encoding='utf-8') as m, open('sources/checksums/v23_SHA256SUMS', 'w') as c:
    for p in new:
        h = sha(p); c.write(f'{h}  {p}\n')
        if p not in have: m.write(f'{p}\t{h}\t{os.path.getsize(p)}\tv23\t{os.path.basename(p)}\n')
print('v23 witnesses applied')
PY
