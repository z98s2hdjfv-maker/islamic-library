#!/bin/bash
# v25: manuscripts catalog, Chittick-Movahhed concordance for Shams, secondary literature entry.
set -euo pipefail
python3 pipeline/verify/check_verifications.py --repo .
python3 - <<'PY'
import os, hashlib
def sha(p):
    h = hashlib.sha256()
    with open(p, 'rb') as f:
        for c in iter(lambda: f.read(1 << 20), b''): h.update(c)
    return h.hexdigest()
new = ['catalogs/manuscripts.tsv', 'catalogs/secondary_literature.tsv', 'reports/concordance/chittick_movahhed.tsv',
       'pipeline/verify/build_chittick_concordance.py', 'docs/verification/MANUSCRIPTS_AND_CONCORDANCE.md']
have = {l.split('\t')[0] for l in open('MANIFEST.tsv', encoding='utf-8')}
with open('MANIFEST.tsv', 'a', encoding='utf-8') as m, open('sources/checksums/v25_SHA256SUMS', 'w') as c:
    for p in new:
        h = sha(p); c.write(f'{h}  {p}\n')
        if p not in have: m.write(f'{p}\t{h}\t{os.path.getsize(p)}\tv25\t{os.path.basename(p)}\n')
row = ("| catalogs/manuscripts.tsv | **Manuscripts and concordance (v25):** the manuscripts behind each edition "
       "(library, shelfmark, copyist, evidence, source; from the St Andrews Islamisation of Anatolia database and "
       "the editions' introductions), and reports/concordance/chittick_movahhed.tsv mapping Chittick's Me & Rumi "
       "citations to our Shams OCR records. See docs/verification/MANUSCRIPTS_AND_CONCORDANCE.md. |\n")
L = open('CORPUS_LOCATIONS.md', encoding='utf-8').read().splitlines(keepends=True)
if not any('catalogs/manuscripts.tsv' in l for l in L):
    i = next(k for k, l in enumerate(L) if l.startswith('| reports/collation/'))
    L.insert(i + 1, row); open('CORPUS_LOCATIONS.md', 'w', encoding='utf-8').writelines(L)
print('v25 applied')
PY
